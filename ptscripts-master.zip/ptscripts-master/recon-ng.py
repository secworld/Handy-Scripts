#!/usr/bin/python -tt

print """
    _/_/_/    _/_/_/_/    _/_/_/    _/_/    _/      _/              _/      _/    _/_/_/
   _/    _/  _/        _/        _/    _/  _/_/    _/              _/_/    _/  _/
  _/_/_/    _/_/_/    _/        _/    _/  _/  _/  _/  _/_/_/_/_/  _/  _/  _/  _/  _/_/
 _/    _/  _/        _/        _/    _/  _/    _/_/              _/    _/_/  _/    _/
_/    _/  _/_/_/_/    _/_/_/    _/_/    _/      _/              _/      _/    _/_/_/

This script has been replaced by the Recon-ng Framework.

https://bitbucket.org/LaNMaSteR53/recon-ng

Thank you.

@LaNMaSteR53  
"""
